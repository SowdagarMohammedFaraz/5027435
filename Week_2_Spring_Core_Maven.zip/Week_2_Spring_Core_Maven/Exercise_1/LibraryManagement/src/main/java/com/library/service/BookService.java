package com.library.service;


public class BookService {

    public void manageBooks() {
        System.out.println("Managing books...");
    }
}
