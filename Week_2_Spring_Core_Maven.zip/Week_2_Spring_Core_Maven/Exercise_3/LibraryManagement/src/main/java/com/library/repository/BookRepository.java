package com.library.repository;

public class BookRepository {
    public void fetchBooks() {
        System.out.println("Fetching books...");
    }
}
